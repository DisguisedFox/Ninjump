namespace KeyboardAndMouseExample
{
	using UnityEngine;


	// This file is intentionally left blank to prevent errors because
	// Unity does not delete asset folders when importing new versions.
	public class CubeController : MonoBehaviour
	{
		void Start()
		{
			Debug.LogError( "Custom profiles are now deprecated. This example is left blank to prevent errors when importing new versions of InControl." );
		}
	}
}

