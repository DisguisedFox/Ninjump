// This file is intentionally left blank to prevent errors because 
// Unity does not delete asset folders when importing new versions.