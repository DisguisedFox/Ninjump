﻿namespace InControl
{
	public enum NativeDeviceTransportType : ushort
	{
		Unknown,
		USB,
		Bluetooth,
	}
}

