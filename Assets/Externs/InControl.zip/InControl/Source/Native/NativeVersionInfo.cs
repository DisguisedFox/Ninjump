﻿namespace InControl
{
	using System;


	public struct NativeVersionInfo
	{
		public UInt32 major;
		public UInt32 minor;
		public UInt32 patch;
		public UInt32 build;
	}
}

