﻿namespace InControl
{
	public enum TouchUnitType : int
	{
		Percent,
		Pixels
	}
}