﻿namespace InControl
{
	public enum TouchType : int
	{
		Direct,
		Indirect,
		Stylus,
		Mouse
	}
}